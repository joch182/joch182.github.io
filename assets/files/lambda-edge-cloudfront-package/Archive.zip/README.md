### Folders ecdsa, jose, pyasn1 and rsa must be kept exactly how they are. DO NOT DELETE, IF UPDATE YOU NEED TO TEST BEFORE DEPLOYING.
