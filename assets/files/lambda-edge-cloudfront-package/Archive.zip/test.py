import json
import urllib3
from jose import jwk
from jose.utils import base64url_decode
import traceback

def verify_token_signature(token):
  for idx, k in enumerate(token_signing_keys):
      pub_key = jwk.construct(k)
      try:
          encoded_sig = token.rsplit('.', 1)[1]
          header, message = token.rsplit('.', 1)
          decoded_sig = base64url_decode(encoded_sig.encode())
          pub_key.verify(message.encode('utf-8'), decoded_sig)
          return {
              'status': 200,
              'pub_key': pub_key
          }
      except Exception as e:
          print(e)
          print(traceback.format_exc())
          if len(token_signing_keys) == idx+1:
              return {
                  'status': 401
              }
          else:
              pass
    
            
access_token = "INSERT_ACCESS_TOKEN_HERE_FOR_TESTING"

refresh_token = "INSERT_REFRESH_TOKEN_HERE_FOR_TESTING"

id_token = "INSERT_ID_TOKEN_HERE_FOR_TESTING"

TOKEN_SIGN_URL = "<Token_signing_key_URL>" # This is located in cognito user pool: User pool overview


http = urllib3.PoolManager()

token_signing = http.request('GET', TOKEN_SIGN_URL)
token_signing_keys = json.loads(token_signing.data.decode('utf-8'))['keys']

print(verify_token_signature(access_token))
print(verify_token_signature(refresh_token))
print(verify_token_signature(id_token))
