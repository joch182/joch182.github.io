from jose import jwt, jwk, jws, jwe
from jose.utils import base64url_decode
import urllib3
import json

def verify_token_signature(token):
    for idx, k in enumerate(token_signing_keys):
        pub_key = jwk.construct(k)
        message, encoded_sig = token.rsplit('.', 1)
        decoded_sig = base64url_decode(encoded_sig.encode())
        try:
            pub_key.verify(message, decoded_sig)
            return {
                'status': 200,
                'pub_key': pub_key,
                'key': k
            }
        except:
            if len(token_signing_keys) == idx+1:
                return {
                    'status': 401
                }
            
access_token = "INSERT_ACCESS_TOKEN_HERE_FOR_TESTING"

refresh_token = "INSERT_REFRESH_TOKEN_HERE_FOR_TESTING"

id_token = "INSERT_ID_TOKEN_HERE_FOR_TESTING"

TOKEN_SIGN_URL = "<Token_signing_key_URL>" # This is located in cognito user pool: User pool overview


http = urllib3.PoolManager()

token_signing = http.request('GET', TOKEN_SIGN_URL)
token_signing_keys = json.loads(token_signing.data.decode('utf-8'))['keys']

print(verify_token_signature(access_token))
print(verify_token_signature(refresh_token))
print(verify_token_signature(id_token))
