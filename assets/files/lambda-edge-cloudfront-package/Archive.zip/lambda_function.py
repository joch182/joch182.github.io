import json
import urllib3
from http.cookies import SimpleCookie
from jose import jwk, jwt, JWTError

cookie = SimpleCookie()

AUTH_URL = "<COGNITO_URL_DOMAIN>" # This can be the custom or the generated domain by Cognito
COGNITO_CLIENT_ID = "<CLIENT_ID>" # This is located in cognito user pool: App Integration -> App clients and analytics
BASE_URL = "<Main_Page_URL_After_Successfull_Login>"
TOKEN_SIGN_URL = "<Token_Signing_Key_URL>" # This is located in cognito user pool: User pool overview
DOMAIN = 'yourdomain.com'

http = urllib3.PoolManager()
token_signing_keys = json.loads(http.request('GET', TOKEN_SIGN_URL).data.decode('utf-8'))['keys']

def lambda_handler(event, context):
  request = event["Records"][0]["cf"]["request"]
  cf = event["Records"][0]["cf"]
  headers = request["headers"]
  print(f"CF = {cf}")
  print('Started...')
  if 'referer' in headers and headers['referer'][0]['value'] == AUTH_URL and request['querystring'].startswith('code='):
      # User loging in. Get Token and add to cookie
      referer = headers['referer'][0]['value']
      code = request['querystring'].split('code=')[1]
      tokens = get_tokens(code)
      tokens['verifitcation'] = verify_tokens(tokens)
      if tokens['verifitcation']['status'] != 200:
          # Auth failed
          print('Auth Failed')
          response = {
              'status': '302',
              'statusDescription': 'Redirect',
              'headers': {
                  'location': [{
                      'key': 'Location',
                      'value': AUTH_URL+'login?client_id='+COGNITO_CLIENT_ID+'&response_type=code&scope=email+openid&redirect_uri='+BASE_URL
                  }]
              }
          }
      else:
          # Auth succeeded
          print('Auth Succeed')
          response = {
              'status': '302',
              'statusDescription': 'Redirect',
              'headers': {
                  'location': [{
                      'key': 'Location',
                      'value': BASE_URL+'index.html'
                  }],
                  'content-type': [{
                      "key": "content-type",
                      "value": "text/html"
                  }],
                  'set-cookie': [{
                      'key': 'Set-Cookie',
                      'value': f"id_token={tokens['id_token']}; path=/; Secure; HttpOnly; SameSite=Lax; Domain="+DOMAIN+";"
                  },{
                      'key': 'Set-Cookie',
                      'value': f"access_token={tokens['access_token']}; path=/; Secure; HttpOnly; SameSite=Lax; Domain="+DOMAIN+";"
                  },{
                      'key': 'Set-Cookie',
                      'value': f"refresh_token={tokens['refresh_token']}; path=/; Secure; HttpOnly; SameSite=Lax; Domain="+DOMAIN+";"
                  }
                  ]
              }
          }
      return json.loads(json.dumps(response, default=str))
  elif 'cookie' in headers and len(headers['cookie'][0]['value'].split("id_token=")) > 1 and len(headers['cookie'][0]['value'].split("access_token=")) > 1 and len(headers['cookie'][0]['value'].split("refresh_token=")) > 1:
      # Check cookies
      cookie.load(headers['cookie'][0]['value'])
      cookies = {}
      for key, val in cookie.items():
          cookies[key] = val.value
      print(f"Cookies: {cookies}")
      cookies['verifitcation'] = verify_tokens(cookies)
      if cookies['verifitcation']['status'] != 200:
          # Try to refresh the id and access tokens
          refresh_tokens = get_refresh_token(cookies['refresh_token'])
          if refresh_tokens['status'] == 200:
              # New valid tokens
              if 'uri' not in request:
                  request['uri'] = "/index.html"
              response = {
                  'status': '302',
                  'statusDescription': 'Redirect',
                  'headers': {
                      'location': [{
                          'key': 'Location',
                          'value': BASE_URL+request['uri']
                      }],
                      'content-type': [{
                          "key": "content-type",
                          "value": "text/html"
                      }],
                      'set-cookie': [{
                          'key': 'Set-Cookie',
                          'value': f"id_token={refresh_tokens['tokens']['id_token']}; path=/; Secure; HttpOnly; SameSite=Lax; Domain="+DOMAIN+";"
                      },{
                          'key': 'Set-Cookie',
                          'value': f"access_token={refresh_tokens['tokens']['access_token']}; path=/; Secure; HttpOnly; SameSite=Lax; Domain="+DOMAIN+";"
                      }
                      ]
                  }
              }
              return json.loads(json.dumps(response, default=str))
          else:
              # Token Invalid
              print('Tokens invalid')
              response = {
                  'status': '302',
                  'statusDescription': 'Redirect',
                  'headers': {
                      'location': [{
                          'key': 'Location',
                          'value': AUTH_URL+'login?client_id='+COGNITO_CLIENT_ID+'&response_type=code&scope=email+openid&redirect_uri='+BASE_URL
                      }],
                      'content-type': [{
                          "key": "content-type",
                          "value": "text/html"
                      }],
                      'set-cookie': [{
                          'key': 'Set-Cookie',
                          'value': f"id_token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;"
                      },{
                          'key': 'Set-Cookie',
                          'value': f"access_token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;"
                      },{
                          'key': 'Set-Cookie',
                          'value': f"refresh_token=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;"
                      }
                      ]
                  }
              }
      else:
          # Token Valid
          print('Token Valid')
          if 'uri' in request and request['uri'] == "/logout.html":
              # Sign out
              response = {
                  'status': '302',
                  'statusDescription': 'Redirect',
                  'headers': {
                      'location': [{
                          'key': 'Location',
                          'value': AUTH_URL+'logout?client_id='+COGNITO_CLIENT_ID+'&response_type=code&scope=email+openid&redirect_uri='+BASE_URL
                      }],
                      'content-type': [{
                          "key": "content-type",
                          "value": "text/html"
                      }],
                      'set-cookie': [{
                          "key": "content-type",
                          "value": "text/html"
                      }],
                      'set-cookie': [{
                          'key': 'Set-Cookie',
                          'value': f"id_token=deleted; path=/; Domain="+DOMAIN+"; expires=Thu, 01 Jan 1970 00:00:00 GMT"
                      },{
                          'key': 'Set-Cookie',
                          'value': f"access_token=deleted; path=/; Domain="+DOMAIN+"; expires=Thu, 01 Jan 1970 00:00:00 GMT"
                      },{
                          'key': 'Set-Cookie',
                          'value': f"refresh_token=deleted; path=/; Domain="+DOMAIN+"; expires=Thu, 01 Jan 1970 00:00:00 GMT"
                      }
                      ]
                  }
              }
              print(f"Delete Cookies: {response}")
              return json.loads(json.dumps(response, default=str))
          return request
      return json.loads(json.dumps(response, default=str))
  else:
      # No Auth. No Tokens. Redirect to Auth page.
      response = {
              'status': '302',
              'statusDescription': 'Redirect',
              'headers': {
                  'location': [{
                      'key': 'Location',
                      'value': AUTH_URL+'login?client_id='+COGNITO_CLIENT_ID+'&response_type=code&scope=email+openid&redirect_uri='+BASE_URL
                  }]
              }
          }
      return json.loads(json.dumps(response, default=str))  

def get_tokens(code):
  headers = { 
      'Content-Type' : 'application/x-www-form-urlencoded'
  }
  url = f"{AUTH_URL}oauth2/token?grant_type=authorization_code&code={code}&client_id={COGNITO_CLIENT_ID}&redirect_uri={BASE_URL}"
  response = http.request('POST', url, headers=headers)
  return json.loads(response.data.decode('utf-8'))

def verify_tokens(tokens):
  try:
    decoded_token = jwt.decode(tokens['id_token'], token_signing_keys, algorithms=["RS256"], audience=COGNITO_CLIENT_ID, access_token=tokens['access_token'])
    return {
        'status': 200
    }
  except JWTError as e:
    print("Token is invalid:", str(e))
    return {
        'status': 401,
        'error': str(e)
    }
  
def get_refresh_token(refresh_token):
  try:
      resp = http.request_encode_body(
        "POST",
        AUTH_URL+"oauth2/token",
        encode_multipart=False,
        fields={
          "grant_type": "refresh_token",
          "client_id": COGNITO_CLIENT_ID,
          "refresh_token": refresh_token
        },
        headers={
          "Content-Type": "application/x-www-form-urlencoded"
        }
      )
      return {
        'status': 200,
        'tokens': json.loads(resp.data.decode('utf-8')) # Return dict
      }
  except Exception as e:
      return {
          'status': 401,
          'error': str(e)
      }
    
