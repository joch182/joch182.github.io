import json
import urllib3
from http.cookies import SimpleCookie
from jose import jwk
from jose.utils import base64url_decode

cookie = SimpleCookie()

AUTH_URL = "<COGNITO_URL_DOMAIN>" # This can be the custom or the generated domain by Cognito
COGNITO_CLIENT_ID = "<CLIENT_ID>" # This is located in cognito user pool: App Integration -> App clients and analytics
BASE_URL = "<Main_Page_URL_After_Successfull_Login>"
TOKEN_SIGN_URL = "<Token_Signing_Key_URL>" # This is located in cognito user pool: User pool overview

http = urllib3.PoolManager()
token_signing_keys = json.loads(http.request('GET', TOKEN_SIGN_URL).data.decode('utf-8'))['keys']

def lambda_handler(event, context):
    request = event["Records"][0]["cf"]["request"]
    cf = event["Records"][0]["cf"]
    headers = request["headers"]
    print(f"CF = {cf}") # We can view this in Cloudwatch
    if 'referer' in headers and headers['referer'][0]['value'] == AUTH_URL and request['querystring'].startswith('code='):
        # User loging in. Get Token and add to cookie
        referer = headers['referer'][0]['value']
        code = request['querystring'].split('code=')[1]
        tokens = get_tokens(code)
        access_token_verification = verify_token_signature(tokens['access_token'])
        id_token_verification = verify_token_signature(tokens['id_token'])
        refresh_token_verification = verify_token_signature(tokens['refresh_token'])
        
        if access_token_verification['status'] != 200 or id_token_verification['status'] != 200 or refresh_token_verification['status'] != 200:
            # Auth failed
            print('Auth Failed')
            response = {
                'status': '302',
                'statusDescription': 'Redirect',
                'headers': {
                    'location': [{
                        'key': 'Location',
                        'value': AUTH_URL+'login?client_id='+COGNITO_CLIENT_ID+'&response_type=code&scope=email+openid&redirect_uri='+BASE_URL
                    }]
                }
            }
        else:
            # Auth succeeded
            print('Auth Succeed')
            response = {
                'status': '302',
                'statusDescription': 'Redirect',
                'headers': {
                    'location': [{
                        'key': 'Location',
                        'value': BASE_URL+'index.html'
                    }],
                    'content-type': [{
                        "key": "content-type",
                        "value": "text/html"
                    }],
                    'set-cookie': [{
                        'key': 'Set-Cookie',
                        'value': f"id={tokens['id_token']}; Secure; HttpOnly; SameSite=Lax; Domain=yourdomain.com;"
                    },{
                        'key': 'Set-Cookie',
                        'value': f"access={tokens['access_token']}; Secure; HttpOnly; SameSite=Lax; Domain=yourdomain.com;"
                    },{
                        'key': 'Set-Cookie',
                        'value': f"refresh={tokens['refresh_token']}; Secure; HttpOnly; SameSite=Lax; Domain=yourdomain.com;"
                    }
                    ]
                }
            }
        return json.loads(json.dumps(response, default=str))
    elif 'cookie' in headers:
        # Check cookies
        cookie.load(headers['cookie'][0]['value'])
        cookies = {}
        for key, val in cookie.items():
            cookies[key] = val.value
        print(f"Cookies: {cookies}")
        access_token_verification = verify_token_signature(cookies['access'])
        id_token_verification = verify_token_signature(cookies['id'])
        refresh_token_verification = verify_token_signature(cookies['refresh'])
        if access_token_verification['status'] != 200 or id_token_verification['status'] != 200 or refresh_token_verification['status'] != 200:
            # Token Invalid
            print('Tokens invalid')
            response = {
                'status': '302',
                'statusDescription': 'Redirect',
                'headers': {
                    'location': [{
                        'key': 'Location',
                        'value': AUTH_URL+'login?client_id='+COGNITO_CLIENT_ID+'&response_type=code&scope=email+openid&redirect_uri='+BASE_URL
                    }],
                    'content-type': [{
                        "key": "content-type",
                        "value": "text/html"
                    }],
                    'set-cookie': [{
                        'key': 'Set-Cookie',
                        'value': f"id=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;"
                    },{
                        'key': 'Set-Cookie',
                        'value': f"access=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;"
                    },{
                        'key': 'Set-Cookie',
                        'value': f"refresh=deleted; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;"
                    }
                    ]
                }
            }
        else:
            # Token Valid
            print('Token Valid')
            return request
        return json.loads(json.dumps(response, default=str))
    else:
        # No Auth. No Tokens. Redirect to Auth page.
        response = {
                'status': '302',
                'statusDescription': 'Redirect',
                'headers': {
                    'location': [{
                        'key': 'Location',
                        'value': AUTH_URL+'login?client_id='+COGNITO_CLIENT_ID+'&response_type=code&scope=email+openid&redirect_uri='+BASE_URL
                    }]
                }
            }
        return json.loads(json.dumps(response, default=str))
                  
def get_tokens(code):
    headers = { 
        'Content-Type' : 'application/x-www-form-urlencoded'
    }
    url = f"{AUTH_URL}oauth2/token?grant_type=authorization_code&code={code}&client_id={COGNITO_CLIENT_ID}&redirect_uri={BASE_URL}"
    response = http.request('POST', url, headers=headers)
    return json.loads(response.data.decode('utf-8'))

def verify_token_signature(token):
    for idx, k in enumerate(token_signing_keys):
        pub_key = jwk.construct(k)
        message, encoded_sig = token.rsplit('.', 1)
        decoded_sig = base64url_decode(encoded_sig.encode())
        try:
            pub_key.verify(message, decoded_sig)
            return {
                'status': 200,
                'pub_key': pub_key
            }
        except:
            if len(token_signing_keys) == idx+1:
                return {
                    'status': 401
                }
            else:
                pass